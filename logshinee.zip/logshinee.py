from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
import sys
from functools import wraps

app = Flask(__name__)
# Configuración de mensajes flash para la interfaz de usuario
app.config['SECRET_KEY'] = 'mi_clave_secreta_super_segura' 
app.config['SESSION_TYPE'] = 'filesystem' # Configuración de sesión necesaria para 'logged_in'

# --- Configuración de la base de datos ---
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'tiendita'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor' 

mysql = MySQL(app)

# ----------------- Decorador de Autenticación -----------------

def login_required(f):
    """
    Decorador que verifica si el usuario ha iniciado sesión. 
    Si no, lo redirige a la página de login.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            flash('Por favor, inicia sesión para acceder a esta página.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ----------------- Funciones Auxiliares -----------------

def convert_unitario_to_float(compras):
    """Convierte campos numéricos de compras y ventas a float/int para Jinja/JSON."""
    if isinstance(compras, dict):
        compras_list = [compras]
    elif isinstance(compras, list):
        compras_list = compras
    else:
        return compras

    for compra in compras_list:
        if 'unitario' in compra:
            try:
                compra['unitario'] = float(compra['unitario'])
            except (TypeError, ValueError):
                compra['unitario'] = 0.0
        if 'monto' in compra:
            try:
                compra['monto'] = float(compra['monto'])
            except (TypeError, ValueError):
                compra['monto'] = 0.0
        if 'precio_unitario' in compra:
            try:
                compra['precio_unitario'] = float(compra['precio_unitario'])
            except (TypeError, ValueError):
                compra['precio_unitario'] = 0.0
        if 'total' in compra:
            try:
                compra['total'] = float(compra['total'])
            except (TypeError, ValueError):
                compra['total'] = 0.0
        if 'stock' in compra:
            try:
                compra['stock'] = int(compra['stock'])
            except (TypeError, ValueError):
                compra['stock'] = 0
        if 'cantidad' in compra:
            try:
                compra['cantidad'] = int(compra['cantidad'])
            except (TypeError, ValueError):
                compra['cantidad'] = 1
    
    return compras_list[0] if isinstance(compras, dict) and compras_list else compras_list

def verify_and_update_db_schema():
    """Asegura que las tablas compras y ventas tengan la estructura correcta con stock."""
    try:
        cursor = mysql.connection.cursor()
        
        # 1. Verificar si existe la columna 'stock' en la tabla 'compras'
        cursor.execute("SHOW COLUMNS FROM compras LIKE 'stock'")
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE compras ADD COLUMN stock INT NOT NULL DEFAULT 0")
            mysql.connection.commit()

        # 2. Recrear/asegurar la tabla 'ventas' con la estructura adecuada
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS ventas (
            id_venta INT AUTO_INCREMENT PRIMARY KEY,
            cliente_dni VARCHAR(255) NOT NULL,
            producto_ref VARCHAR(255) NOT NULL,
            cantidad INT NOT NULL DEFAULT 1,
            monto DECIMAL(10,2) NOT NULL,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        # Verificar si falta 'cantidad' o 'cliente_dni' en la tabla ventas previa
        cursor.execute("SHOW COLUMNS FROM ventas LIKE 'cliente_dni'")
        if not cursor.fetchone():
            cursor.execute("DROP TABLE IF EXISTS ventas")
            cursor.execute("""
            CREATE TABLE ventas (
                id_venta INT AUTO_INCREMENT PRIMARY KEY,
                cliente_dni VARCHAR(255) NOT NULL,
                producto_ref VARCHAR(255) NOT NULL,
                cantidad INT NOT NULL DEFAULT 1,
                monto DECIMAL(10,2) NOT NULL,
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            mysql.connection.commit()

        cursor.close()
    except Exception as e:
        print(f"Aviso durante la verificación de esquema DB: {e}", file=sys.stderr)

def get_compra(id_compra):
    """Obtiene un registro de compra por su ID con su stock."""
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock FROM compras WHERE id_compra = %s", (id_compra,))
    compra = cursor.fetchone()
    cursor.close()
    
    if compra:
        compra = convert_unitario_to_float(compra)
    
    return compra

def get_ventas_list():
    """Obtiene la lista de ventas registradas con datos formateados."""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id_venta, cliente_dni, producto_ref, cantidad, monto, fecha FROM ventas ORDER BY id_venta DESC")
        ventas = cursor.fetchall()
        cursor.close()
        return convert_unitario_to_float(ventas)
    except Exception as e:
        print(f"Error al obtener ventas: {e}", file=sys.stderr)
        return []


# ----------------- Rutas de Autenticación -----------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Maneja el inicio de sesión del usuario."""
    if request.method == 'POST':
        USERNAME = 'admin'
        PASSWORD = 'password'
        
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == USERNAME and password == PASSWORD:
            session['logged_in'] = True
            session['username'] = username
            flash('¡Sesión iniciada correctamente!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Credenciales inválidas. Inténtalo de nuevo.', 'error')
            return render_template('login.html')
            
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Cierra la sesión del usuario."""
    session.pop('logged_in', None)
    session.pop('username', None)
    flash('Has cerrado sesión exitosamente.', 'info')
    return redirect(url_for('login'))


# ----------------- Rutas de Gestión de Compras / Inventario -----------------

@app.route('/')
@login_required
def index():
    """Muestra la lista de compras/inventario y ventas registradas."""
    verify_and_update_db_schema()
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock FROM compras ORDER BY id_compra DESC")
        compras = cursor.fetchall()
        cursor.close()
        
        compras = convert_unitario_to_float(compras)
        ventas = get_ventas_list()
        
        return render_template('index.html', compras=compras, ventas=ventas, search_query=None, compra_a_editar=None)
    except Exception as e:
        print(f"Error al conectar/consultar la base de datos: {e}", file=sys.stderr)
        return render_template('index.html', error_msg=f"Error de conexión a la base de datos. Detalles: {e}", compras=[], ventas=[], compra_a_editar=None)

@app.route('/add', methods=['POST'])
@login_required
def add():
    """Inserta un nuevo producto/compra con stock inicial."""
    if request.method == 'POST':
        try:
            id_compra = request.form['id_compra']
            nombre = request.form['nombre']
            marca = request.form['marca']
            modelo = request.form['modelo']
            presentacion = request.form['presentacion']
            proveedor = request.form['proveedor']
            unitario = float(request.form['unitario'])
            stock = int(request.form.get('stock', 0))
            
            cursor = mysql.connection.cursor()
            query = """
            INSERT INTO compras (id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock))
            mysql.connection.commit()
            cursor.close()

            flash('Producto/Compra agregado exitosamente con stock', 'success')
            return redirect(url_for('index'))

        except ValueError:
            flash('Error: El costo unitario y el stock deben ser números válidos.', 'error')
            return redirect(url_for('index'))
        except Exception as e:
            print(f"Error al procesar la compra: {e}", file=sys.stderr)
            flash(f'Error al agregar compra: {e}', 'error')
            return redirect(url_for('index'))

@app.route('/edit/<int:compra_id>')
@login_required
def edit(compra_id):
    """Carga los datos de una compra específica para el formulario de edición."""
    compra_a_editar = get_compra(compra_id)
    
    if not compra_a_editar:
        flash('Registro de compra no encontrado.', 'error')
        return redirect(url_for('index'))
    
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock FROM compras ORDER BY id_compra DESC")
        compras = cursor.fetchall()
        compras = convert_unitario_to_float(compras)
        cursor.close()
    except Exception as e:
        print(f"Error al obtener listado de compras en edición: {e}", file=sys.stderr)
        compras = []

    ventas = get_ventas_list()

    return render_template('index.html', compras=compras, ventas=ventas, search_query=None, compra_a_editar=compra_a_editar)

@app.route('/update/<int:compra_id>', methods=['POST'])
@login_required
def update(compra_id):
    """Actualiza un registro de compra e inventario existente."""
    if request.method == 'POST':
        try:
            id_compra = request.form['id_compra']
            nombre = request.form['nombre']
            marca = request.form['marca']
            modelo = request.form['modelo']
            presentacion = request.form['presentacion']
            proveedor = request.form['proveedor']
            unitario = float(request.form['unitario'])
            stock = int(request.form.get('stock', 0))
            
            cursor = mysql.connection.cursor()
            query = """
            UPDATE compras SET 
                id_compra = %s,
                nombre = %s, 
                marca = %s, 
                modelo = %s, 
                presentacion = %s, 
                proveedor = %s, 
                unitario = %s,
                stock = %s
            WHERE id_compra = %s
            """
            cursor.execute(query, (id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock, compra_id))
            mysql.connection.commit()
            cursor.close()
            
            flash('Registro actualizado exitosamente', 'success')
            return redirect(url_for('index'))

        except ValueError:
            flash('Error: Verifica que costo unitario y stock sean valores válidos.', 'error')
            return redirect(url_for('edit', compra_id=compra_id)) 
        except Exception as e:
            print(f"Error al actualizar la compra: {e}", file=sys.stderr)
            flash(f'Error al actualizar compra: {e}', 'error')
            return redirect(url_for('edit', compra_id=compra_id))

@app.route('/delete/<int:compra_id>', methods=['POST'])
@login_required
def delete(compra_id):
    """Elimina una compra de la base de datos."""
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("DELETE FROM compras WHERE id_compra = %s", (compra_id,))
        mysql.connection.commit()
        cursor.close()

        flash(f'Compra ID {compra_id} eliminada exitosamente.', 'danger')
    except Exception as e:
        print(f"Error al eliminar la compra: {e}", file=sys.stderr)
        flash(f'Error al eliminar la compra ID {compra_id}: {e}', 'error')
        
    return redirect(url_for('index'))

@app.route('/search', methods=['GET'])
@login_required
def search():
    """Busca compras por ID."""
    search_query = request.args.get('id_compra')

    if not search_query:
        return redirect(url_for('index'))

    try:
        cursor = mysql.connection.cursor()
        query = "SELECT id_compra, nombre, marca, modelo, presentacion, proveedor, unitario, stock FROM compras WHERE id_compra = %s"
        cursor.execute(query, (search_query,))
        
        results = cursor.fetchall()
        cursor.close()
        
        results = convert_unitario_to_float(results)
        ventas = get_ventas_list()

        if results:
            flash(f'Se encontró {len(results)} compra(s) con ID "{search_query}"', 'info')
        else:
            flash(f'No se encontraron compras con ID "{search_query}"', 'warning')
        
        return render_template('index.html', compras=results, ventas=ventas, search_query=search_query, compra_a_editar=None)

    except Exception as e:
        print(f"Error en la búsqueda de la base de datos: {e}", file=sys.stderr)
        flash('Error al realizar la búsqueda en la base de datos.', 'error')
        return redirect(url_for('index'))


# ----------------- RUTA DE VENTAS CON AFECTACIÓN AL STOCK -----------------

@app.route('/add_sale', methods=['POST'])
@login_required
def add_sale():
    """
    Procesa y guarda una venta, descontando la cantidad vendida del stock
    de la tabla compras si producto_ref coincide con id_compra o nombre.
    """
    if request.method == 'POST':
        try:
            cliente_dni = request.form['cliente_dni']
            producto_ref = request.form['producto_ref']
            cantidad = int(request.form.get('cantidad', 1))
            monto = float(request.form['monto'])

            if cantidad <= 0:
                flash('La cantidad a vender debe ser mayor a 0.', 'error')
                return redirect(url_for('index'))

            cursor = mysql.connection.cursor()

            # Buscar si producto_ref coincide con id_compra o nombre en la tabla compras para descontar stock
            cursor.execute("SELECT id_compra, stock FROM compras WHERE id_compra = %s OR nombre = %s", (producto_ref, producto_ref))
            producto = cursor.fetchone()

            if producto:
                stock_actual = int(producto['stock'])
                id_compra_encontrado = producto['id_compra']

                if stock_actual < cantidad:
                    flash(f'Stock insuficiente para "{producto_ref}". Disponible: {stock_actual}, Solicitado: {cantidad}', 'error')
                    cursor.close()
                    return redirect(url_for('index'))

                # Descontar del stock
                nuevo_stock = stock_actual - cantidad
                cursor.execute("UPDATE compras SET stock = %s WHERE id_compra = %s", (nuevo_stock, id_compra_encontrado))

            # Registrar la venta en la tabla ventas
            query = "INSERT INTO ventas (cliente_dni, producto_ref, cantidad, monto) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (cliente_dni, producto_ref, cantidad, monto))

            mysql.connection.commit()
            cursor.close()

            flash(f'Venta registrada con éxito. Stock de "{producto_ref}" actualizado.', 'success')
            return redirect(url_for('index'))

        except ValueError:
            flash('Error: El monto y la cantidad deben ser números válidos.', 'error')
            return redirect(url_for('index'))
        except Exception as e:
            mysql.connection.rollback()
            print(f"Error al registrar la venta: {e}", file=sys.stderr)
            flash(f'Error al registrar la venta: {e}', 'error')
            return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)